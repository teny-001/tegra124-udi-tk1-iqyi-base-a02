#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
dtb2mainline.py -- 把 NVIDIA 下游 3.10 风格的 DTB 反编译结果重写成
Linux 内核主线 (upstream) 风格的 DTS 源码。

与 `dtc -I dtb -O dts` 的区别：
  * 数字 phandle -> label 引用 (&gpio / &tegra_car / &palmas ...)
  * 中断三元组魔数 -> GIC_SPI / GIC_PPI + IRQ_TYPE_*
  * GPIO 编号魔数 -> TEGRA_GPIO(bank, offset) + GPIO_ACTIVE_*
  * pinmux 0/1/2/3 -> TEGRA_PIN_* 宏
  * linux,code 116 -> KEY_POWER
  * 属性按内核 dts-coding-style 排序，status 置末
  * 有 reg 但无 unit-address 的节点补上 @地址
  * 丢弃 nvidia,dtsfilename / nvidia,boardids 等下游产物

用法: dtb2mainline.py <in.dtb> <out.dts>
"""
import struct
import sys

# ---------------------------------------------------------------- DTB 解析


class Node(object):
    __slots__ = ('name', 'props', 'children', 'parent')

    def __init__(self, name, parent):
        self.name = name
        self.props = []
        self.children = []
        self.parent = parent


def parse_dtb(data):
    (magic, totalsize, off_struct, off_strings, off_rsv,
     version, last_comp, boot_cpu, size_strings, size_struct) = \
        struct.unpack_from('>10I', data, 0)
    if magic != 0xd00dfeed:
        raise SystemExit('not a dtb (magic=%08x)' % magic)

    strings = data[off_strings:off_strings + size_strings]

    def gstr(off):
        end = strings.find(b'\0', off)
        return strings[off:end].decode('latin1')

    cur = off_struct
    end = off_struct + size_struct
    stack = []
    root = None
    while cur < end:
        tok = struct.unpack_from('>I', data, cur)[0]
        cur += 4
        if tok == 1:                                   # FDT_BEGIN_NODE
            nul = data.find(b'\0', cur)
            name = data[cur:nul].decode('latin1')
            cur = (nul + 1 + 3) & ~3
            node = Node(name, stack[-1] if stack else None)
            if stack:
                stack[-1].children.append(node)
            else:
                root = node
            stack.append(node)
        elif tok == 2:                                 # FDT_END_NODE
            stack.pop()
        elif tok == 3:                                 # FDT_PROP
            plen, nameoff = struct.unpack_from('>II', data, cur)
            cur += 8
            val = data[cur:cur + plen]
            cur = (cur + plen + 3) & ~3
            stack[-1].props.append((gstr(nameoff), val))
        elif tok == 4:                                 # FDT_NOP
            pass
        elif tok == 9:                                 # FDT_END
            break
        else:
            raise SystemExit('bad token %d at %d' % (tok, cur))
    return root, version, boot_cpu


def node_path(n):
    parts = []
    while n is not None:
        parts.append(n.name)
        n = n.parent
    parts.reverse()
    if len(parts) == 1:
        return '/'
    return '/' + '/'.join(parts[1:])


def walk(n, path=''):
    for c in n.children:
        p = (path + '/' + c.name) if path else '/' + c.name
        yield p, c
        for x in walk(c, p):
            yield x


def u32s(val):
    return list(struct.unpack('>%dI' % (len(val) // 4), val))


def is_string(val):
    if not val or val[-1] != 0:
        return False
    body = val[:-1]
    if not body:
        return False
    parts = body.split(b'\0')
    # 字符串列表里不允许出现空串（否则多半是 0x00000048 这类数字被误判）
    if any(p == b'' for p in parts):
        return False
    for b in body:
        if b != 0 and not (0x20 <= b <= 0x7e):
            return False
    return True


# ---------------------------------------------------------------- 映射表

RENAME = {
    '/clock': 'clock@60006000',
    '/pinmux': 'pinmux@70000868',
    '/pmc': 'pmc@7000e400',
    '/rtc': 'rtc@7000e000',
    '/host1x': 'host1x@50000000',
    '/mipical': 'mipical@7000e300',
    '/memory': 'memory@0',
    '/memory@0x80000000': 'memory@80000000',
    '/clocks/clock': 'clock@0',
    '/i2c@7000d000/tps65913': 'pmic@58',
}

LABEL = {
    '/interrupt-controller@50041000': 'gic',
    '/interrupt-controller@60004000': 'lic',
    '/gpio@6000d000': 'gpio',
    '/gpio@6000d000/default': 'gpio_default',
    '/pinmux@70000868': 'pinmux',
    '/pinmux@70000868/common': 'pinmux_default',
    '/pinmux@70000868/drive': 'pinmux_drive',
    '/pinmux@70000868/unused_lowpower': 'pinmux_unused_lowpower',
    '/dma@60020000': 'apbdma',
    '/clock@60006000': 'tegra_car',
    '/clocks/clock@0': 'clk32k_in',
    '/pwm@7000a000': 'pwm',
    '/se@70012000': 'se',
    '/pmc@7000e400': 'pmc',
    '/rtc@7000e000': 'rtc',
    '/timer@60005000': 'timer',
    '/host1x@50000000': 'host1x',
    '/host1x@50000000/hdmi': 'hdmi',
    '/host1x@50000000/vic': 'vic',
    '/host1x@50000000/msenc': 'msenc',
    '/host1x@50000000/tsec': 'tsec',
    '/host1x@50000000/gk20a': 'gk20a',
    '/host1x@50000000/nvavp': 'nvavp',
    '/xusb@70090000': 'xusb',
    '/mipical@7000e300': 'mipical',
    '/i2c@7000c000': 'i2c0',
    '/i2c@7000c400': 'i2c1',
    '/i2c@7000c700': 'i2c3',
    '/i2c@7000d000': 'i2c4',
    '/spi@7000d400': 'spi0',
    '/spi@7000da00': 'spi3',
    '/serial@70006000': 'serial0',
    '/serial@70006040': 'serial1',
    '/serial@70006200': 'serial2',
    '/regulators': 'regulators',
    '/regulators/regulator@0': 'vdd_ac_bat',
    '/regulators/regulator@1': 'usb0_vbus',
    '/regulators/regulator@2': 'usb1_vbus',
    '/regulators/regulator@3': 'usb2_vbus',
    '/regulators/regulator@5': 'vddio_sd',
    '/regulators/regulator@8': 'vdd_hdmi_n5',
    '/regulators/regulator@9': 'vddio_hdmi_5v0',
}

PALMAS = '/i2c@7000d000/pmic@58'
LABEL.update({
    PALMAS: 'palmas',
    PALMAS + '/gpio': 'palmas_gpio',
    PALMAS + '/rtc': 'palmas_rtc',
    PALMAS + '/extcon': 'palmas_extcon',
    PALMAS + '/power_pm': 'palmas_power',
    PALMAS + '/gpadc': 'palmas_gpadc',
    PALMAS + '/pinmux': 'palmas_pinctrl',
    PALMAS + '/pinmux/pinmux': 'palmas_pinmux',
    PALMAS + '/pmic': 'palmas_pmic',
    PALMAS + '/pmic/regulators': 'palmas_regulators',
    PALMAS + '/pmic/regulators/smps123': 'vdd_cpu',
    PALMAS + '/pmic/regulators/smps457': 'vdd_gpu',
    PALMAS + '/pmic/regulators/smps6': 'vdd_core',
    PALMAS + '/pmic/regulators/smps8': 'vdd_1v8',
    PALMAS + '/pmic/regulators/smps9': 'vdd_snsr',
    PALMAS + '/pmic/regulators/smps10_out1': 'vdd_out1_5v0',
    PALMAS + '/pmic/regulators/smps10_out2': 'vdd_out2_5v0',
    PALMAS + '/pmic/regulators/ldo1': 'avdd_pll',
    PALMAS + '/pmic/regulators/ldo2': 'avdd_lcd',
    PALMAS + '/pmic/regulators/ldo5': 'avdd_dsi_csi',
    PALMAS + '/pmic/regulators/ldo6': 'vpp_fuse',
    PALMAS + '/pmic/regulators/ldo8': 'vdd_rtc',
    PALMAS + '/pmic/regulators/ldo9': 'vddio_sdmmc_2',
    PALMAS + '/pmic/regulators/ldoln': 'vddio_hv',
    PALMAS + '/pmic/regulators/ldousb': 'avdd_usb',
})

# 有 reg 却没写 unit-address 时,补一个 @ 地址
AUTO_UNIT = True

# 原厂兼容模式（--keep-node-names）：
#   True 时节点名一律保持 DTB 里的原名，不套 RENAME、不补 @地址，
#   并保留 nvidia,boardids / nvidia,dtsfilename。
#   原因：Tegra cboot 在拉起内核前按固定路径读 /pinmux、/clock 配引脚，
#   且要用 nvidia,boardids 匹配板子；这三样一改就 boot loop（2026-11-09 实测）。
KEEP_NODE_NAMES = False

DROP_PROPS = ('nvidia,dtsfilename', 'nvidia,boardids', 'phandle')

# 属性排序:越小越靠前
PRIO = {
    'model': -3, 'compatible': -2, 'label': -1, 'device_type': -1,
    'linux,initrd-start': 20, 'linux,initrd-end': 21,
    'reg': 0, 'pins': 0, 'function': 1, 'reg-names': 1, 'ranges': 2, 'dma-ranges': 3,
    '#address-cells': 4, '#size-cells': 5,
    'interrupt-parent': 6, 'interrupts': 7, 'interrupt-names': 8,
    'interrupt-controller': 9, '#interrupt-cells': 10,
    'clocks': 11, 'clock-names': 12, '#clock-cells': 13, 'clock-frequency': 14,
    'resets': 15, 'reset-names': 16,
    'dmas': 17, 'dma-names': 18,
    'gpio-controller': 19, '#gpio-cells': 20, 'gpios': 21, 'pwms': 21,
    'linux,code': 22,
    'gpio-init-names': 21,
    'nvidia,pins': 22, 'nvidia,function': 23,
    'pinctrl-names': 22,
}

DECIMAL_PROPS = {
    'clock-frequency', 'max_brightness', 'max_volume', 'max_speed',
    'spi-max-frequency', 'linux,code', 'reg-shift',
    'nvidia,pull-down-strength', 'nvidia,pull-up-strength', 'nvidia,drive-type',
    'regulator-min-microvolt', 'regulator-max-microvolt',
    'regulator-init-microvolt',
    'ti,ldousb-in-threshold-voltage', 'ti,threshold-voltage-tolerance',
    'ti,ldousb-in-vbus-threshold-voltage', 'ti,channel3-current-microamp',
    '#address-cells', '#size-cells', '#gpio-cells', '#interrupt-cells',
    '#clock-cells', '#pwm-cells',
}

IRQ_FLAGS = {
    0x0: 'IRQ_TYPE_NONE', 0x1: 'IRQ_TYPE_EDGE_RISING',
    0x2: 'IRQ_TYPE_EDGE_FALLING', 0x3: 'IRQ_TYPE_EDGE_BOTH',
    0x4: 'IRQ_TYPE_LEVEL_HIGH', 0x8: 'IRQ_TYPE_LEVEL_LOW',
}

GPIO_FLAGS = {0x0: 'GPIO_ACTIVE_HIGH', 0x1: 'GPIO_ACTIVE_LOW'}

PIN_BOOL_PROPS = ('nvidia,enable-input', 'nvidia,tristate',
                  'nvidia,open-drain', 'nvidia,lock', 'nvidia,rcv-sel',
                  'nvidia,high-speed-mode', 'nvidia,schmitt')
PIN_ENUM = {
    'nvidia,pull': ('TEGRA_PIN_PULL_NONE', 'TEGRA_PIN_PULL_DOWN',
                    'TEGRA_PIN_PULL_UP'),
    'nvidia,low-power-mode': ('TEGRA_PIN_LP_DRIVE_DIV_8',
                              'TEGRA_PIN_LP_DRIVE_DIV_4',
                              'TEGRA_PIN_LP_DRIVE_DIV_2',
                              'TEGRA_PIN_LP_DRIVE_DIV_1'),
    'nvidia,slew-rate-rising': ('TEGRA_PIN_SLEW_RATE_FASTEST',
                                'TEGRA_PIN_SLEW_RATE_FAST',
                                'TEGRA_PIN_SLEW_RATE_SLOW',
                                'TEGRA_PIN_SLEW_RATE_SLOWEST'),
    'nvidia,slew-rate-falling': ('TEGRA_PIN_SLEW_RATE_FASTEST',
                                 'TEGRA_PIN_SLEW_RATE_FAST',
                                 'TEGRA_PIN_SLEW_RATE_SLOW',
                                 'TEGRA_PIN_SLEW_RATE_SLOWEST'),
}

GPIO_LIST_PROPS = ('gpio-input', 'gpio-output-low', 'gpio-output-high')


def bank_name(bank):
    if bank < 26:
        return chr(ord('A') + bank)
    return chr(ord('A') + bank - 26) * 2


def tegra_gpio(num):
    return 'TEGRA_GPIO(%s, %d)' % (bank_name(num // 8), num % 8)


# ---------------------------------------------------------------- 输出

class Emitter(object):
    def __init__(self, root):
        self.root = root
        self.phandle = {}          # phandle -> path
        self.nodes = {}            # path -> node
        self.newpath = {}          # old path -> new path
        for path, n in walk(root):
            self.nodes[path] = n
        self.nodes['/'] = root
        # 先算 rename 后的路径
        for path in list(self.nodes):
            self.newpath[path] = self.remap(path)
        for path, n in self.nodes.items():
            for k, v in n.props:
                if k == 'phandle' and len(v) == 4:
                    self.phandle[u32s(v)[0]] = path
        # 控制器单元数
        self.cells = {}
        for path, n in self.nodes.items():
            for key, prop in (('#interrupt-cells', 'irq'),
                              ('#gpio-cells', 'gpio'),
                              ('#pwm-cells', 'pwm')):
                val = self.prop(n, key)
                if val is not None and len(val) == 4:
                    self.cells[(path, prop)] = u32s(val)[0]
        # 指向已被裁掉节点的 aliases（保留是为了不改 i2c/spi 总线编号）
        self.alias_note = {}
        al = self.nodes.get('/aliases')
        if al is not None:
            for k, v in al.props:
                tgt = v.rstrip(b'\0').decode('latin1')
                if tgt not in self.nodes:
                    self.alias_note[k] = ' /* %s: node trimmed away */' % tgt

        self.label_of = {}
        rev = dict((v, k) for k, v in self.newpath.items())
        for newpath, lab in LABEL.items():
            old = rev.get(newpath, newpath)
            if old in self.nodes:
                self.label_of[old] = lab

    # -- 工具
    @staticmethod
    def prop(n, name):
        for k, v in n.props:
            if k == name:
                return v
        return None

    def remap(self, path):
        """把 rename 表应用到路径上（逐段）。"""
        if path == '/':
            return '/'
        segs = path.strip('/').split('/')
        out = []
        for i in range(len(segs)):
            sub = '/' + '/'.join(segs[:i + 1])
            if sub in RENAME:
                out.append(RENAME[sub].split('/')[-1])
            else:
                out.append(segs[i])
        return '/' + '/'.join(out)

    def ref(self, ph):
        path = self.phandle.get(ph)
        if path is None:
            return None
        lab = self.label_of.get(path)
        if lab:
            return '&' + lab
        return '&{%s}' % self.newpath.get(path, path)

    def eff_parent(self, n, what):
        """向上找第一个带 interrupt-parent 的节点, 返回 (path, cells)。"""
        cur = n
        while cur is not None:
            v = self.prop(cur, 'interrupt-parent')
            if v is not None and len(v) == 4:
                ph = u32s(v)[0]
                path = self.phandle.get(ph)
                return path, self.cells.get((path, what), 2)
            cur = cur.parent
        return None, 2

    # -- 值渲染
    def cells_to_tokens(self, n, name, nums):
        """把一串 u32 转成 [(token,...)] 分组。返回 (groups, refcells) 或 None。"""
        path = node_path(n)
        # 1) 纯 phandle 引用属性
        if name == 'interrupt-parent' or name.startswith('pinctrl-') \
                or name.startswith('gpio-init-') or name.endswith('-supply'):
            groups = []
            for v in nums:
                r = self.ref(v)
                groups.append([r if r else '0x%x' % v])
            return groups

        # 2) 带 phandle 的 specifier 属性
        refcells = None
        if name in ('clocks', 'resets', 'dmas', 'nvidia,dma-request-selector'):
            refcells = 1
        elif name in ('gpios', 'gpio', 'pwms') or name.endswith('-gpios') \
                or name.endswith('-gpio'):
            refcells = 2
        if refcells is not None and nums:
            groups = []
            i = 0
            while i < len(nums):
                head = nums[i]
                r = self.ref(head)
                body = nums[i + 1:i + 1 + refcells]
                toks = [r if r else '0x%x' % head]
                if refcells == 2 and r and r.startswith('&gpio'):
                    toks.append(tegra_gpio(body[0]))
                    toks.append(GPIO_FLAGS.get(body[1], '0x%x' % body[1]))
                elif refcells == 2 and r and r.startswith('&pwm'):
                    toks.append(str(body[0]))
                    toks.append(str(body[1]))
                else:
                    for b in body:
                        if refcells == 1 and name in ('clocks', 'resets', 'dmas'):
                            toks.append(str(b))
                        else:
                            toks.append('0x%x' % b)
                groups.append(toks)
                i += 1 + refcells
            return groups

        # 2.5) reg 按 父节点 #address-cells + #size-cells 分组
        if name == 'reg' and nums:
            par = n.parent
            ac, sc = 1, 1
            if par is not None:
                v = self.prop(par, '#address-cells')
                if v is not None and len(v) == 4:
                    ac = u32s(v)[0]
                v = self.prop(par, '#size-cells')
                if v is not None and len(v) == 4:
                    sc = u32s(v)[0]
            gsz = ac + sc
            if gsz > 0 and len(nums) % gsz == 0:
                return [[('0x%x' % x) for x in nums[i:i + gsz]]
                        for i in range(0, len(nums), gsz)]

        # 3) interrupts
        if name == 'interrupts':
            cpath, ncells = self.eff_parent(n, 'irq')
            if cpath is None or ncells == 0:
                ncells = 3
            groups = []
            i = 0
            while i + ncells <= len(nums):
                chunk = nums[i:i + ncells]
                i += ncells
                if ncells == 3:
                    kind = 'GIC_SPI' if chunk[0] == 0 else 'GIC_PPI'
                    flag = chunk[2]
                    low = flag & 0xff
                    lt = IRQ_FLAGS.get(low, '0x%x' % low)
                    if flag >> 8:
                        nbits = bin(flag >> 8).count('1')
                        ftok = '(GIC_CPU_MASK_SIMPLE(%d) | %s)' % (nbits, lt)
                    else:
                        ftok = lt
                    groups.append([kind, str(chunk[1]), ftok])
                elif cpath == '/gpio@6000d000' and ncells == 2:
                    groups.append([tegra_gpio(chunk[0]),
                                   IRQ_FLAGS.get(chunk[1], '0x%x' % chunk[1])])
                else:
                    groups.append(['0x%x' % c for c in chunk])
            return groups

        # 4) tegra-gpio-init 的 GPIO 列表
        if name in GPIO_LIST_PROPS:
            return [[tegra_gpio(v) for v in nums]]

        # 5) pinmux 布尔 / 枚举
        if name in PIN_BOOL_PROPS and len(nums) == 1:
            return [['TEGRA_PIN_ENABLE' if nums[0] else 'TEGRA_PIN_DISABLE']]
        if name in PIN_ENUM and len(nums) == 1:
            table = PIN_ENUM[name]
            if 0 <= nums[0] < len(table):
                return [[table[nums[0]]]]
        if name == 'linux,code' and len(nums) == 1 and nums[0] == 116:
            return [['KEY_POWER']]

        return None

    def render_prop(self, n, name, val, indent):
        pad = '\t' * indent
        if len(val) == 0:
            return ['%s%s;' % (pad, name)]
        if is_string(val):
            parts = val.rstrip(b'\0').split(b'\0')
            strs = ', '.join('"%s"' % p.decode('latin1') for p in parts)
            note = ''
            if n is self.nodes.get('/aliases') and name in self.alias_note:
                note = self.alias_note[name]
            return ['%s%s = %s;%s' % (pad, name, strs, note)]
        if len(val) % 4 != 0:
            body = ' '.join('%02x' % b for b in val)
            return ['%s%s = [%s];' % (pad, name, body)]

        nums = u32s(val)
        groups = self.cells_to_tokens(n, name, nums)
        if groups is None:
            if name in DECIMAL_PROPS:
                groups = [[str(v) for v in nums]]
            else:
                groups = [['0x%x' % v for v in nums]]

        rendered = ['<%s>' % ' '.join(g) for g in groups]
        one = '%s%s = %s;' % (pad, name, ', '.join(rendered))
        if len(one) <= 78:
            return [one]

        head = '%s%s = ' % (pad, name)
        cont = pad + ' ' * (len(name) + 3)
        out = []
        for gi, g in enumerate(groups):
            prefix = head if gi == 0 else cont
            suffix = ';' if gi == len(groups) - 1 else ','
            line = '%s<%s>%s' % (prefix, ' '.join(g), suffix)
            if len(line) <= 78:
                out.append(line)
                continue
            cur = prefix + '<'
            start = cur
            for i, t in enumerate(g):
                last = (i == len(g) - 1)
                add = t + ('' if last else ' ')
                if len(cur) + len(add) + 1 > 78 and cur != start:
                    out.append(cur.rstrip())
                    cur = cont + ' '
                cur += add
            out.append(cur + '>' + suffix)
        return out

    def sort_props(self, n):
        props = [(k, v) for k, v in n.props if k not in DROP_PROPS]

        def key(item):
            k = item[0]
            if k in PRIO:
                return (PRIO[k], k)
            if k.startswith('pinctrl-'):
                return (23, k)
            if k == 'status':
                return (999, k)
            return (100, k)

        return sorted(props, key=key)

    def node_name(self, path, n):
        if KEEP_NODE_NAMES:
            return n.name
        if path in RENAME:
            return RENAME[path]
        if AUTO_UNIT and '@' not in n.name:
            reg = self.prop(n, 'reg')
            if reg is not None and len(reg) >= 4:
                addr = u32s(reg)[0]
                if addr:
                    return '%s@%x' % (n.name, addr)
        return n.name

    def emit_node(self, path, n, indent, out):
        pad = '\t' * indent
        name = self.node_name(path, n)
        lab = self.label_of.get(path)
        head = ('%s: %s {' % (lab, name)) if lab else ('%s {' % name)
        out.append(pad + head)
        start = len(out)
        for k, v in self.sort_props(n):
            out.extend(self.render_prop(n, k, v, indent + 1))
        had_props = len(out) > start
        for c in n.children:
            if had_props:
                out.append('')
            self.emit_node(path + '/' + c.name if path != '/' else '/' + c.name,
                           c, indent + 1, out)
            had_props = True
        out.append(pad + '};')

    def build_manifest(self):
        m = {}

        def rec(oldpath, n, newpath):
            m[oldpath] = newpath
            for c in n.children:
                op = (oldpath + '/' + c.name) if oldpath != '/' else '/' + c.name
                nm = self.node_name(op, c)
                np = (newpath + '/' + nm) if newpath != '/' else '/' + nm
                rec(op, c, np)

        rec('/', self.root, '/')
        return m

    def emit_root(self):
        out = []
        n = self.root
        out.append('/ {')
        for k, v in self.sort_props(n):
            out.extend(self.render_prop(n, k, v, 1))
        for c in n.children:
            out.append('')
            self.emit_node('/' + c.name, c, 1, out)
        out.append('};')
        return out


HEADER = '''\
// SPDX-License-Identifier: GPL-2.0
/*
 * NVIDIA Tegra124 TN8 / Ardbeg TV (iQIYI G100) -- mainline style device tree
 *
 * 由 ardbeg-tv-v8c.dtb 反编译后重写而成（原始来源:
 *   arch/arm/boot/dts/tegra124-tn8-p1761-1470-a00.dts,
 *   boardid 1761:1470:0）。
 *
 * 与下游 NVIDIA 3.10 设备树的差异只在"写法"层面:
 *   - 数字 phandle 换成 label 引用
 *   - 中断 / GPIO / pinmux 魔数换成 dt-bindings 宏
 *   - 属性按 dts-coding-style 排序, status 置末
 *   - 有 reg 的节点补 unit-address
 * 属性名与取值保持与 v8c 完全一致, 因此编译出的 DTB 在语义上与 v8c 等价,
 * 可直接给现有的 3.10 内核使用。
 *
 * 仍然保留下游专有 binding（主线无对应实现, 改成主线写法会打断现有驱动）:
 *   nvidia,dma-request-selector, nvidia,memory-clients, gpio-init-N,
 *   nvidia,require-cldvfs-clock, nvidia,bit-banging-xfer-after-shutdown,
 *   consumers / regulator-consumer-*, pwm-beeper / pwm-fan 的 max_* 属性。
 *
 * 时钟 / 复位 ID 仍写成数字: 本机没有 include/dt-bindings/clock/tegra124-car.h,
 * 无法安全地换成 TEGRA124_CLK_* 宏。用到的几个是:
 *   RTC = 4, TIMER = 5, PCLK = 261 (0x105)
 */

/dts-v1/;

#include <dt-bindings/gpio/gpio.h>
#include <dt-bindings/gpio/tegra-gpio.h>
#include <dt-bindings/input/linux-event-codes.h>
#include <dt-bindings/interrupt-controller/arm-gic.h>
#include <dt-bindings/interrupt-controller/irq.h>
#include <dt-bindings/pinctrl/pinctrl-tegra.h>
'''


def main():
    global AUTO_UNIT, KEEP_NODE_NAMES, DROP_PROPS
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    if '--keep-node-names' in sys.argv:
        KEEP_NODE_NAMES = True
        AUTO_UNIT = False
        # 只丢 phandle（label 会重新分配），保留 nvidia,boardids / dtsfilename
        DROP_PROPS = ('phandle',)
    if len(args) < 2:
        raise SystemExit('usage: dtb2mainline.py [--keep-node-names] <in.dtb> <out.dts>')
    src, dst = args[0], args[1]
    data = open(src, 'rb').read()
    root, version, boot_cpu = parse_dtb(data)
    em = Emitter(root)
    body = em.emit_root()
    import json
    man = em.build_manifest()
    with open(dst + '.map.json', 'w') as f:
        json.dump(man, f, indent=0, sort_keys=True)
    with open(dst, 'w') as f:
        f.write(HEADER)
        f.write('\n')
        f.write('\n'.join(body))
        f.write('\n')
    print('wrote %s (%d lines)' % (dst, len(body) + 22))


if __name__ == '__main__':
    main()
