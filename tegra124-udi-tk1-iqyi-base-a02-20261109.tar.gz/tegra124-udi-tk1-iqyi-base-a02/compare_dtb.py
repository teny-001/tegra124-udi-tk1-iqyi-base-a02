#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""compare_dtb.py <orig.dtb> <new.dtb> [map.json]  -- 语义等价性校验

不给 map.json 时按同名路径直接比对（identity 映射），
这能真正暴露"节点被改名/移动"这类问题。
"""
import json
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dtb2mainline import parse_dtb, walk, u32s   # noqa


def collect(root):
    props = {}
    ph = {}
    props['/'] = dict(root.props)
    for path, n in walk(root):
        props[path] = dict(n.props)
    for path, d in props.items():
        v = d.get('phandle')
        if v is not None and len(v) == 4:
            ph[u32s(v)[0]] = path
    return props, ph


def main():
    if len(sys.argv) < 3:
        sys.stderr.write('用法: compare_dtb.py <orig.dtb> <new.dtb> [map.json]\n')
        sys.exit(2)
    a, b = sys.argv[1], sys.argv[2]
    ra, _, _ = parse_dtb(open(a, 'rb').read())
    rb, _, _ = parse_dtb(open(b, 'rb').read())
    pa, pha = collect(ra)
    pb, phb = collect(rb)
    if len(sys.argv) > 3:
        mapping = json.load(open(sys.argv[3]))
    else:
        mapping = {p: p for p in pa}

    errs = []
    # 1) 节点集合
    expect = set(mapping.values())
    have = set(pb.keys())
    for p in sorted(expect - have):
        errs.append('MISSING node %s' % p)
    for p in sorted(have - expect):
        errs.append('EXTRA node %s' % p)

    # 2) 属性逐个比对
    nprop = 0
    for opath, oprops in sorted(pa.items()):
        npath = mapping.get(opath, opath)
        nprops = pb.get(npath)
        if nprops is None:
            continue
        for k, v in oprops.items():
            if k == 'phandle':
                continue
            if k not in nprops:
                if k in ('nvidia,dtsfilename', 'nvidia,boardids'):
                    continue
                errs.append('%s: prop %s LOST' % (opath, k))
                continue
            nv = nprops[k]
            nprop += 1
            if v == nv:
                continue
            if len(v) % 4 or len(nv) % 4 or len(v) != len(nv):
                errs.append('%s: prop %s len %d != %d' % (opath, k, len(v), len(nv)))
                continue
            ca, cb = u32s(v), u32s(nv)
            for i, (x, y) in enumerate(zip(ca, cb)):
                if x == y:
                    continue
                na = pha.get(x)
                nb = phb.get(y)
                if na and nb and mapping.get(na, na) == nb:
                    continue
                errs.append('%s: prop %s cell[%d] %#x -> %#x (%s / %s)'
                            % (opath, k, i, x, y, na, nb))
        for k in nprops:
            if k not in oprops and k != 'phandle':
                errs.append('%s: prop %s ADDED' % (opath, k))

    print('nodes: orig=%d new=%d   props compared=%d' % (len(pa), len(pb), nprop))
    if errs:
        print('!! %d 处不一致' % len(errs))
        for e in errs[:40]:
            print('   ', e)
        sys.exit(1)
    print('OK: 语义完全一致')


if __name__ == '__main__':
    main()
