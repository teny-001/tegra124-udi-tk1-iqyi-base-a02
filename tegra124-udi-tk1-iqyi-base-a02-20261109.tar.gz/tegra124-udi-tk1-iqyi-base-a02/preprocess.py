#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""极简 C 预处理器 —— 只为编译 DTS 服务。

为什么需要它
------------
dtc 自带的预处理器不支持函数式宏（TEGRA_GPIO(C, 4) 这类），
所以 DTS 必须先过一遍 C 预处理器。常规做法是 cpp，但很多精简系统
（容器、最小化发行版、WSL 基础镜像）里根本没装 gcc/clang。

本脚本实现 DTS 真正用到的那一小撮特性，让"解压即可编译"成立：

    #include "file"       相对当前文件
    #include <file>       相对 -I 目录
    #define NAME body     对象宏
    #define F(a,b) body   函数宏（支持 ## 拼接）
    #ifndef / #endif      仅 include guard 用法
    其它 # 开头的行        原样输出（#address-cells 等 dtc 属性名）

这与 gcc 在 -x assembler-with-cpp 模式下的行为一致：不认识的行首 # 保留。

用法
----
    python3 preprocess.py -I. -Idtbinds -o /tmp/pre.dts board.dts
"""

import os
import re
import sys

IDENT = re.compile(r'[A-Za-z_]\w*')

# macros: name -> (params or None, body)
#   params = None 表示对象宏；否则是参数名列表


def strip_comments(text):
    """剥离 /* */ 与 // 注释，字符串字面量内的内容保持不动。"""
    out = []
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c == '"':
            j = i + 1
            while j < n:
                if text[j] == '\\':
                    j += 2
                    continue
                if text[j] == '"':
                    j += 1
                    break
                j += 1
            out.append(text[i:j])
            i = j
        elif text.startswith('/*', i):
            j = text.find('*/', i + 2)
            j = n if j < 0 else j + 2
            # 用空格顶替，避免把两侧 token 粘在一起
            out.append(' ')
            i = j
        elif text.startswith('//', i):
            j = text.find('\n', i)
            i = n if j < 0 else j
        else:
            out.append(c)
            i += 1
    return ''.join(out)


def join_continuations(text):
    """把反斜杠续行拼成一行（cpp 是直接删掉反斜杠+换行）。"""
    return re.sub(r'\\[ \t]*\r?\n', '', text)


def parse_args(s, k):
    """s[k] == '('，返回 (顶层逗号切分的实参列表, 右括号之后的下标)。"""
    depth = 0
    i = k
    args = []
    cur = []
    n = len(s)
    while i < n:
        c = s[i]
        if c in '([':
            depth += 1
            if depth > 1:
                cur.append(c)
        elif c in ')]':
            depth -= 1
            if depth == 0:
                args.append(''.join(cur).strip())
                return args, i + 1
            cur.append(c)
        elif c == ',' and depth == 1:
            args.append(''.join(cur).strip())
            cur = []
        else:
            cur.append(c)
        i += 1
    return None, k


def substitute(params, body, args, macros, hide):
    """把宏体里的形参换成实参，并处理 ## 拼接。"""
    raw = dict(zip(params, args))

    # 1) ## 拼接：两侧若是形参用"未展开"的原文
    def glue(m):
        a, b = m.group(1), m.group(2)
        return raw.get(a, a) + raw.get(b, b)

    body = re.sub(r'(\w+)[ \t]*##[ \t]*(\w+)', glue, body)

    # 2) 其余形参用"已展开"的实参替换
    def repl(m):
        name = m.group()
        if name in raw:
            return expand(raw[name], macros, hide)
        return name

    body = IDENT.sub(repl, body)

    # 3) 拼接产物（如 TEGRA_GPIO_BANK_ID_C）再整体展开
    return expand(body, macros, hide)


def expand_once(s, macros, hide):
    out = []
    i, n = 0, len(s)
    while i < n:
        m = IDENT.match(s, i)
        if not m:
            out.append(s[i])
            i += 1
            continue
        name = m.group()
        j = m.end()
        if name in macros and name not in hide:
            params, body = macros[name]
            if params is None:
                out.append(expand(body, macros, hide | {name}))
                i = j
                continue
            # 函数宏：后面（允许空白）必须跟 '(' 才算调用
            k = j
            while k < n and s[k] in ' \t\r\n':
                k += 1
            if k < n and s[k] == '(':
                args, end = parse_args(s, k)
                if args is not None and len(args) == len(params):
                    out.append(substitute(params, body, args,
                                          macros, hide | {name}))
                    i = end
                    continue
        out.append(name)
        i = j
    return ''.join(out)


def expand(s, macros, hide=frozenset()):
    """反复展开直到稳定，最多 32 轮（防 A->A 这类自引用死循环）。"""
    for _ in range(32):
        t = expand_once(s, macros, hide)
        if t == s:
            return t
        s = t
    return s


DEFINE_RE = re.compile(r'^[ \t]*#[ \t]*define[ \t]+([A-Za-z_]\w*)(\(([^)]*)\))?(.*)$')
INCLUDE_RE = re.compile(r'^[ \t]*#[ \t]*include[ \t]+([<"])([^>"]+)[>"]')
IFNDEF_RE = re.compile(r'^[ \t]*#[ \t]*ifndef[ \t]+([A-Za-z_]\w*)')
ENDIF_RE = re.compile(r'^[ \t]*#[ \t]*endif\b')


class Preprocessor(object):
    def __init__(self, incdirs):
        self.incdirs = incdirs
        self.macros = {}
        self.out = []

    def find_include(self, name, angle, curdir):
        if not angle:
            p = os.path.join(curdir, name)
            if os.path.exists(p):
                return p
        for d in self.incdirs:
            p = os.path.join(d, name)
            if os.path.exists(p):
                return p
        return None

    def run(self, path):
        path = os.path.abspath(path)
        curdir = os.path.dirname(path)
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            text = f.read()
        text = join_continuations(strip_comments(text))

        # ifndef 栈：True 表示当前块生效
        stack = []
        for line in text.split('\n'):
            active = all(stack)

            m = INCLUDE_RE.match(line)
            if m:
                if not active:
                    continue
                angle = m.group(1) == '<'
                name = m.group(2)
                p = self.find_include(name, angle, curdir)
                if p is None:
                    sys.stderr.write('错误: 找不到 %s\n' % name)
                    sys.exit(1)
                self.run(p)
                continue

            m = IFNDEF_RE.match(line)
            if m:
                sym = m.group(1)
                stack.append(sym not in self.macros)
                if stack[-1]:
                    self.macros[sym] = (None, '1')
                continue

            if ENDIF_RE.match(line):
                if stack:
                    stack.pop()
                continue

            m = DEFINE_RE.match(line)
            if m:
                if not active:
                    continue
                name = m.group(1)
                if m.group(2) is not None:
                    plist = [p.strip() for p in m.group(3).split(',')
                             if p.strip()]
                    self.macros[name] = (plist, m.group(4).strip())
                else:
                    self.macros[name] = (None, m.group(4).strip())
                continue

            # 其它以 # 开头的行（#address-cells 等）原样输出
            if not active:
                continue
            self.out.append(expand(line, self.macros))

        return self.out


def main():
    argv = sys.argv[1:]
    incdirs, outpath, src = [], None, None
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == '-I':
            incdirs.append(argv[i + 1])
            i += 2
        elif a.startswith('-I'):
            incdirs.append(a[2:])
            i += 1
        elif a == '-o':
            outpath = argv[i + 1]
            i += 2
        else:
            src = a
            i += 1

    if not src:
        sys.stderr.write('用法: python3 preprocess.py -I. -Idtbinds -o out.dts in.dts\n')
        sys.exit(1)

    pp = Preprocessor(incdirs or ['.'])
    lines = pp.run(src)
    data = '\n'.join(lines)
    if outpath:
        with open(outpath, 'w', encoding='utf-8') as f:
            f.write(data)
    else:
        sys.stdout.write(data)


if __name__ == '__main__':
    main()
